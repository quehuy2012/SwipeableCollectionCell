//
//  ZADragTransitionLayout.h
//  SwipeCellKit
//
//  Created by CPU11713 on 4/12/17.
//  Copyright © 2017 CPU11713. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "ZASwipeable.h"

@interface ZADragTransitionLayout : NSObject <ZASwipeTransitionLayout>

@end
