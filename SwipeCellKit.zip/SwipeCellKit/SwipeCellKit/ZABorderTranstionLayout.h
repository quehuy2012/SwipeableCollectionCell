//
//  ZABorderTranstionLayout.h
//  ZaloMessageUI
//
//  Created by CPU11713 on 4/4/17.
//  Copyright © 2017 CPU11713. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "ZASwipeable.h"

@interface ZABorderTranstionLayout : NSObject <ZASwipeTransitionLayout>

@end
